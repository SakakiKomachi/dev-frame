<h2>Daftar Buku</h2>
<h3><?php echo e($sub_judul); ?></h3>
<?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($b); ?><br/>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\21.01.4671\Komachixx\resources\views/list.blade.php ENDPATH**/ ?>