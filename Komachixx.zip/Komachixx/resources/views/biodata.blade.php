<h2>Tambahkan Biodata Anda</h2>
<table>
    <form method="post">
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td><input name="nama" type="text" size=20 /></td>
        </tr>
        <tr>
            <td>Email</td>
            <td>:</td>
            <td><input name="email" type="text" size=20 /></td>
        </tr>
        <tr>
            <td>No. Hp</td>
            <td>:</td>
            <td><input name="no_hp" type="text" size=20 /></td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td><input type="submit" value="kirim" size=20 /></td>
        </tr>
    </from>
</table>